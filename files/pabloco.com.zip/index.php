<!DOCTYPE html>
<html>
	<head>
		<title>Proyecto Web en Git</title>
	</head>
	<body>
		Esto es una linea iniciallllll<br>
		se van a incluir los archivos junto con la carpeta
	</body>
</html>