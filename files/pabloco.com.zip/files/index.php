<?php
	echo "esta es la carpeta de los archivos";
?>