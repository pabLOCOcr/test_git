<?php
	echo "estas en la carpeta  de los estilos";
?>